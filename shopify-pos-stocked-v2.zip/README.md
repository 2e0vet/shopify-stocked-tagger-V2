# Shopify POS-Style Stock Tagger (v2 — with Stock Locations)

Full-screen POS-style app for scanning barcodes, tagging products (STOCKED), and showing **stock by location**.
